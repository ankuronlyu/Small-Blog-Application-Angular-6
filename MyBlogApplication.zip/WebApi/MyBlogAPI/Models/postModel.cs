﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyBlogAPI.Models
{
    public class postModel
    {
        public int PostID { get; set; }
        public string PostTitle { get; set; }
        public string PostShortDescription { get; set; }
        public string PostDescription { get; set; }
        public Nullable<int> CategoryID { get; set; }
        public int CreatedBy { get; set; }
        public Nullable<int> DeletedBy { get; set; }
        public Nullable<int> UpdatedBy { get; set; }
        public bool Isactive { get; set; }
        public System.DateTime CreateDate { get; set; }
        public Nullable<System.DateTime> DeleteDate { get; set; }
        public Nullable<System.DateTime> UpdateDate { get; set; }
        public int UserID { get; set; }

    }
}