﻿using Microsoft.Owin.Security;
using Microsoft.Owin.Security.OAuth;
using MyBlogAPI.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;

namespace MyBlogAPI
{
    public class ApplicationOAuthProvider : OAuthAuthorizationServerProvider
    {
        public override async Task ValidateClientAuthentication(OAuthValidateClientAuthenticationContext context)
        {
            context.Validated();
        }
        public override async Task GrantResourceOwnerCredentials(OAuthGrantResourceOwnerCredentialsContext context)
        {
            Entity.UserInfo user = null;
            List<string> Roles = null;
            using(Entity.BlogDBEntities db=new BlogDBEntities())
            {

                user = db.UserInfoes.Where(n => n.UserName == context.UserName && n.Password == context.Password && n.Isactive==true).FirstOrDefault();
                if (user != null)
                {
                    Roles = (from usrRole in db.UserRoles
                             join r in db.Roles on usrRole.RoleID equals r.RoleID
                             where usrRole.UserID == user.UserID
                             select r.RoleName).ToList();


                }                
            }
            if(user!=null)
            {                
                var identity = new ClaimsIdentity(context.Options.AuthenticationType);
                identity.AddClaim(new Claim("UserName", user.UserName));
                identity.AddClaim(new Claim("UserID", user.UserID.ToString()));
                identity.AddClaim(new Claim("EmailID", user.EmailID));
                identity.AddClaim(new Claim("FirstName", user.FirstName));
                identity.AddClaim(new Claim("LastName", user.LastName));
                identity.AddClaim(new Claim("LoggedOn", DateTime.Now.ToString()));
                foreach(string v in Roles)
                {
                    identity.AddClaim(new Claim(ClaimTypes.Role, v));
                }
                var ExtraInfo = new AuthenticationProperties(new Dictionary<string, string>{
                    {
                        "role", Newtonsoft.Json.JsonConvert.SerializeObject(Roles)
                    }
                });
                var token = new AuthenticationTicket(identity, ExtraInfo);
                context.Validated(token);
            }
            else
            {
                return;
            }
        }

        public override Task TokenEndpoint(OAuthTokenEndpointContext context)
        {
            foreach (KeyValuePair<string, string> property in context.Properties.Dictionary)
            {
                context.AdditionalResponseParameters.Add(property.Key, property.Value);
            }

            return Task.FromResult<object>(null);
        }
    }
}