import { Component, OnInit } from '@angular/core';
import { MenuComponent } from '../menu/menu.component';


@Component({
  selector: 'app-home-public',
  templateUrl: './home-public.component.html',
  styleUrls: ['./home-public.component.css']
})
export class HomePublicComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
