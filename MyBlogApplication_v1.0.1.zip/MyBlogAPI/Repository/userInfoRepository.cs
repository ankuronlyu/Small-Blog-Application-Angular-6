﻿using MyBlogAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MyBlogAPI.Entity;
using System.Data.Entity;

namespace MyBlogAPI.Repository
{
    public class userInfoRepository
    {
       
        /// <summary>
        /// Sign up or User Registration
        /// </summary>
        /// <param name="user">userInfo Model object</param>
        /// <returns>enum Status</returns>
        public LIB.Status UserRegistration(userInfoModel user)
        {
            try
            {
                if (user != null)
                {
                    using (Entity.BlogDBEntities db = new BlogDBEntities())
                    {
                        string _userName = db.UserInfoes.Where(n => n.UserName == user.UserName).Select(x => x.UserName).FirstOrDefault();
                        if (!string.IsNullOrEmpty(_userName))
                            return LIB.Status.AreadyExists;
                        else
                        {
                            var _firstUser = db.UserInfoes.Count();
                            int _userRole = (int)(_firstUser == 0 ? LIB.UserRoles.Admin : LIB.UserRoles.StandardUser);
                            UserInfo userEntity = new UserInfo
                            {
                                UserName = user.UserName,
                                FirstName = user.FirstName,
                                LastName = user.LastName,
                                Password = user.Password,
                                Isactive = true,
                                EmailID = user.EmailID,
                                CreateDate = DateTime.Now,
                            };
                            db.UserInfoes.Add(userEntity);
                            db.SaveChanges();
                            if (userEntity != null)
                            {
                                db.UserRoles.Add(new UserRole
                                {
                                    UserID = userEntity.UserID,
                                    RoleID = _userRole,
                                    CreateDate = DateTime.Now
                                });
                            }
                            db.SaveChanges();
                            return LIB.Status.success;

                        }
                    }
                }
                else
                {
                    return LIB.Status.faile;
                }
            }
            catch (Exception)
            {
                return LIB.Status.faile;
            }
           
            
        }

        public List<userInfoModel> GetUsersList()
        {
            List<userInfoModel> model = new List<userInfoModel>();
            try
            {
                using (Entity.BlogDBEntities db = new BlogDBEntities())
                {
                    model = (from u in db.UserInfoes
                             select new userInfoModel
                             {
                                 UserID = u.UserID,
                                 UserName = u.UserName,
                                 FirstName = u.FirstName,
                                 LastName = u.LastName,
                                 Isactive = u.Isactive,
                                 CreateDate = u.CreateDate,
                                 DeleteDate = u.DeleteDate,
                                 UpdateDate = u.UpdateDate,
                                 EmailID = u.EmailID,
                                 Roles = u.UserRoles.Select(n => n.Role.RoleName).ToList()
                             }
                           ).ToList();

                }

                return model;
            }
            catch (Exception)
            {
                return model;
            }
           
        } 

        public LIB.Status InactiveUser(int userID)
        {
            try
            {
                if (userID > 0)
                {
                    using (Entity.BlogDBEntities db = new BlogDBEntities())
                    {
                        Entity.UserInfo user = db.UserInfoes.Where(n => n.UserID == userID).FirstOrDefault();
                        user.Isactive = false;
                        user.DeleteDate = DateTime.Now;
                        db.Entry(user).State = EntityState.Modified;
                        int flg = db.SaveChanges();
                        if (flg > 0)
                        {
                            return LIB.Status.success;
                        }
                        else
                        {
                            return LIB.Status.faile;
                        }
                    }
                }
                else
                {
                    return LIB.Status.faile;
                }
            }
            catch (Exception)
            {
                return LIB.Status.faile;
            }
            
        }
        
    }
}