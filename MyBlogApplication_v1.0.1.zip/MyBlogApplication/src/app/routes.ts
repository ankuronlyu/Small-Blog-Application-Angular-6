import { Routes } from "@angular/router";
import { HomeComponent } from "./home/home.component";
import { UserComponent } from "./user/user.component";
import { SignUpComponent } from "./user/sign-up/sign-up.component";
import { SignInComponent } from "./user/sign-in/sign-in.component";
import { AuthGuard } from "./auth/auth.guard";
import { AdminPanelComponent } from "./admin-panel/admin-panel.component";
import { UnauthorizeComponent } from "./unauthorize/unauthorize.component";
import { HomePublicComponent } from "./home-public/home-public.component";
import { BlogListComponent } from "./blog-list/blog-list.component";
import { patch } from "webdriver-js-extender";
import { CreateBlogComponent } from "./user/create-blog/create-blog.component";


export const appRoutes: Routes=[

    {path:'CreateBlog',component:CreateBlogComponent,canActivate:[AuthGuard]},
    {path:'Index',component:HomePublicComponent},   
    {path:'blogList',component:BlogListComponent}, 
    {path:'home',component:HomeComponent,canActivate:[AuthGuard]},
    {path:'unautorize',component:UnauthorizeComponent,canActivate:[AuthGuard]},
    {path:'adminPanel',component:AdminPanelComponent,canActivate:[AuthGuard],data:{roles:['Admin']}},
    {path:'signup',component:UserComponent,
    children:[{path:'',component:SignUpComponent}]
    },

    {path:'login',component:UserComponent,
    children:[{path:'',component:SignInComponent}]
    },
    {path:'',redirectTo:'/Index',pathMatch:'full'}
];
