import { Component, OnInit } from '@angular/core';
import { UserService } from '../../shared/user.service';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { MenuComponent } from '../../menu/menu.component';

@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.css']
})
export class SignInComponent implements OnInit {
  isLoginError : boolean = false;
  constructor(private userService:UserService,private router: Router) { }

  ngOnInit() {
  }
  OnSubmit(userName,password){
    this.userService.userAuthentication(userName,password).subscribe((data : any)=>{
      if(data){
        localStorage.setItem('userToken',data.access_token);
        localStorage.setItem('userRole',data.role);
        localStorage.setItem('userDetail',data);
        this.router.navigate(['/home']);
      }
   },
   (err : HttpErrorResponse)=>{
     console.log("Error in Login");
     console.info(HttpErrorResponse);
     this.isLoginError = true;
   });
 }
 }
