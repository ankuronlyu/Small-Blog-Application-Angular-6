import { Component, OnInit } from '@angular/core';
import { MenuForPanelComponent } from '../../menu-for-panel/menu-for-panel.component';
import { BlogService } from '../../shared/blog.service';
import { ToastrService } from 'ngx-toastr';
import { NgForm } from '@angular/forms'
import { BlogPost } from '../../shared/blog-post.model';

@Component({
  selector: 'app-create-blog',
  templateUrl: './create-blog.component.html',
  styleUrls: ['./create-blog.component.css']
})
export class CreateBlogComponent implements OnInit {

  
  constructor(private blogService:BlogService,private toastr: ToastrService) { }
  userDetail:any;
  BlogsList:any;  
 
  ngOnInit() {
    this.getBlogList();
    this.resetForm();
  }

  resetForm(form?: NgForm) {
    if (form != null) 
      form.reset();
    this.blogService.selectedBlog = {
      PostID : null,
      PostTitle :'',
      PostShortDescription:'',
      PostDescription:'',
      CategoryID:null,
      CreatedBy:null,
      DeletedBy:null,
      UpdatedBy:null,
      Isactive:null,
      CreateDate:null,
      DeleteDate:null,
      UpdateDate:null,
    }
  }

  getBlogList(){
    this.blogService.getListBlog().subscribe((data:any)=>{
      var _blogList = [];
      data.forEach(element => {
        var newObj:BlogPost={
          PostID : element['PostID'],
          PostTitle :element['PostTitle'],
          PostShortDescription:null,
          PostDescription:null,
          CategoryID:null,
          CreatedBy:null,
          Isactive:true,
          CreateDate:new Date(Date.now())      
        };
        _blogList.push({ 
          "PostID" : newObj.PostID,
          "PostTitle"  : newObj.PostTitle          
      });
      });
      console.info(_blogList);
      this.BlogsList=_blogList;
      console.log(this.BlogsList);
    });
  }

  showForEdit(blogID : number){
    //get blog details.
    this.blogService.getBlog(blogID).subscribe((data:any)=>{
      console.info(data);
      var selectedBlog:BlogPost={
        PostID : data['PostID'],
        PostTitle :data['PostTitle'],
        PostShortDescription:data['PostShortDescription'],
        PostDescription:data['PostDescription'],
        CategoryID:null,
        CreatedBy:null,
        Isactive:true,
        CreateDate:new Date(Date.now())     
      };
      this.resetForm();
      this.blogService.selectedBlog=selectedBlog;
    });
  }

  OnSubmit(form: NgForm){
    if(form.value.PostID==null){
      //Create new Blog
      
      this.blogService.createBlog(form.value,null)
      .subscribe((data:any)=>{
        console.info(data);
        if(data!=null && data==0){
         this.resetForm(form);
         this.getBlogList();
         this.toastr.success('Blog Created Successfully!.');
         //reload the list
       }
        else{                    
          this.toastr.error("Error! please try again.");
        }
      });
    }
    else{
      this.blogService.UpdateBLog(form.value,null)
      .subscribe((data:any)=>{
        console.info(data);
        if(data!=null && data==0){
         this.resetForm(form);
         this.getBlogList();
         this.toastr.success('Blog Updated Successfully!.');
         //reload the list
       }
        else{                    
          this.toastr.error("Error! please try again.");
        }
      });
    }
  }


}
