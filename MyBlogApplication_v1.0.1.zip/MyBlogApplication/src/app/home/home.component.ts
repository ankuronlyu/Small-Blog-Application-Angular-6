import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../shared/user.service';
import { MenuForPanelComponent } from '../menu-for-panel/menu-for-panel.component';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  userDetails:any;
  userRole:any;
  constructor(private router:Router,private userService: UserService) { }

  ngOnInit() {
    this.userService.getUserDetails().subscribe((data:any)=>{
      localStorage.setItem("userDetail",data);
      this.userDetails=data;
      console.log(data);
      this.userRole= localStorage.getItem("userRole");      
    });       
  }
}
