export class UserInfo {
    UserID		:number;
    UserName	:string;
    FirstName	:string;
    LastName	:string;
    EmailID		:string;
    Password	:string;
    Isactive	:boolean;
   
}
