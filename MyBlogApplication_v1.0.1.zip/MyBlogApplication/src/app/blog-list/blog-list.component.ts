import { Component, OnInit } from '@angular/core';
import { MenuComponent } from '../menu/menu.component';
import { BlogService } from '../shared/blog.service';
import { BlogPost } from '../shared/blog-post.model';

@Component({
  selector: 'app-blog-list',
  templateUrl: './blog-list.component.html',
  styleUrls: ['./blog-list.component.css']
})
export class BlogListComponent implements OnInit {

  BlogsList:any;
  readBlog:any;
  constructor(private blogServie:BlogService) { }

  ngOnInit() {  
    this.getTop10Blog();
    this.getLatestBlog();  
  }

  getTop10Blog(){
    this.blogServie.getTop10Blog().subscribe((data:any)=>{
     if(data){     
      var _blogList = [];
      data.forEach(element => {
       _blogList.push({ 
          "PostID" :element['PostID'],
          "PostTitle"  : element['PostTitle'],          
      });
      });
      this.BlogsList=_blogList;
    }    
    });
  }

  getLatestBlog(){
    //get blog details.
    this.blogServie.getLatestBlog().subscribe((data:any)=>{
      if(data){
        var selectedBlog:BlogPost={
          PostID : data['PostID'],
          PostTitle :data['PostTitle'],
          PostShortDescription:data['PostShortDescription'],
          PostDescription:data['PostDescription'],
          CategoryID:null,
          CreatedBy:null,
          Isactive:true,
          CreateDate:new Date(Date.now())    
      }  
      };     
      this.readBlog=selectedBlog;
    });
  }

  getReadBlog(ID:number){
    //get blog details.
    this.blogServie.getBlog(ID).subscribe((data:any)=>{
      if(data){
      console.log('LatestBlog.');
      console.info(data);
      var selectedBlog:BlogPost={
        PostID : data['PostID'],
        PostTitle :data['PostTitle'],
        PostShortDescription:data['PostShortDescription'],
        PostDescription:data['PostDescription'],
        CategoryID:null,
        CreatedBy:null,
        Isactive:true,
        CreateDate:new Date(Date.now())  
      }   
      };     
      this.readBlog=selectedBlog;
    });
  }

}
