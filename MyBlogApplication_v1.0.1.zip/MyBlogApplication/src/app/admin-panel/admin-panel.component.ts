import { Component, OnInit } from '@angular/core';
import { UserService } from '../shared/user.service';
import { UserInfo } from '../shared/user.model';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-admin-panel',
  templateUrl: './admin-panel.component.html',
  styleUrls: ['./admin-panel.component.css']
})
export class AdminPanelComponent implements OnInit {

  UserList:any;
  constructor(private userService:UserService,private toastr: ToastrService) { }

  ngOnInit() {
   this.getUserList();
  }

  getUserList(){
    this.userService.getUserList().subscribe((data:any)=>{
      var _userArry=[];
      if(data){
        data.forEach(element => {
          _userArry.push({ 
            "UserID"		:element['UserID'],
            "UserName"	:element['UserName'],
            "FirstName"	:element['FirstName'],
            "LastName"	:element['LastName'],
            "EmailID"		:element['EmailID'],
            "Password"	:element['Passowrd'],
            "Isactive"	:element['Isactive']         
        });
        });
        this.UserList=_userArry;
      }   
    });
  }

  inActiveUser(userID:number){
    if(confirm('Do you want to delete this reocrds?')==true)
    this.userService.inActiveUser(userID).subscribe((data:any)=>{ 
        if(data!=null && data==0){         
          this.getUserList();
         this.toastr.success('User Inactivated Successfully! ');
       }
       else if(data!=null && data>1){
         this.toastr.warning('Error! please try again.');
        }
    })

  }

}
