import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { map, take } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {  Response, Jsonp } from "@angular/http";
import { UserInfo } from './user.model';
import { HttpRequest } from 'selenium-webdriver/http';



@Injectable({
  providedIn: 'root'
})
export class UserService {
  readonly rootUrl = 'http://localhost:6830/';
  constructor(private http: HttpClient) { }

  registerUser(user: UserInfo){
    const body: UserInfo = {
      UserID		:user.UserID,
      UserName	:user.UserName,
      FirstName	:user.FirstName,
      LastName	:user.LastName,
      EmailID		:user.EmailID,
      Password	:user.Password,
      Isactive	:true,      
    }
    var result=this.http.post(this.rootUrl+"api/UserInfoes/",body);
    return result;
  }

  changeUserRole(UserID:number,IsAdmin:boolean){
    var body={'UserID':UserID,'IsAdmin':IsAdmin};
    var result=this.http.post(this.rootUrl+"api/ChangeUserRole",body,{headers:new HttpHeaders({'Authorization':'Bearer '+localStorage.getItem('userToken')})});
    return result;
  }


  
  userAuthentication(userName,Password){
    try {
      var data="userName="+userName+"&password="+Password+"&grant_type=password";
      var reqHeader=new HttpHeaders({"Content-Type":"application-/x-wwww-urlencoded"});
      return this.http.post(this.rootUrl+"/token",data,{headers: reqHeader});
      
    } catch (error) {
      console.info(error);
      return;
      
    }
   

  }

  getUserDetails(){
   return this.http.get(this.rootUrl+"/api/GetLoginUser",{headers:new HttpHeaders({'Authorization':'Bearer '+localStorage.getItem('userToken')})});
  }

  getUserList(){
    return this.http.get(this.rootUrl+"/api/GetUserList",{headers:new HttpHeaders({'Authorization':'Bearer '+localStorage.getItem('userToken')})});
   }
 
   inActiveUser(UserID: number){
    return this.http.delete(this.rootUrl+"api/UserInfoes/"+UserID,{headers:new HttpHeaders({'Authorization':'Bearer '+localStorage.getItem('userToken')})});
   
  }


  roleMatch(allowedRoles):boolean{
    var isMatch=false;
    var userRole:string[]=JSON.parse(localStorage.getItem("userRole"));
    allowedRoles.forEach(element => {
      if(userRole.indexOf(element)>-1){
        isMatch=true;
        return false;
      }
    });
    return isMatch;
  }
  
}
