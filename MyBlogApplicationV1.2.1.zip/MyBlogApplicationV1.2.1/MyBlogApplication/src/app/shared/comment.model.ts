export class Comment {
    CommentID?:number;
    Comment:string;
    PostID?:number;    
    CreatedBy?:number;    
    Isactive?:boolean;
    CreateDate?:Date;   
}
