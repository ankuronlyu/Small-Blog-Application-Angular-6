import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { map, take } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {  Response, Jsonp } from "@angular/http";
import { UserInfo } from './user.model';
import { BlogPost } from './blog-post.model';
import { HttpRequest } from 'selenium-webdriver/http';
import { forEach } from '@angular/router/src/utils/collection';
import { NULL_EXPR } from '@angular/compiler/src/output/output_ast';
import { Comment } from './comment.model';

@Injectable({
  providedIn: 'root'
})
export class BlogService {
  
  selectedBlog : BlogPost;
  blogList : BlogPost[];
  readonly rootUrl = 'http://localhost:6830/';
  constructor(private http: HttpClient) { }
 

  createBlog(newBlog:BlogPost,loginUserID:number){
    const body : BlogPost={
        PostID : newBlog.PostID,
        PostTitle :newBlog.PostTitle,
        PostShortDescription:newBlog.PostShortDescription,
        PostDescription:newBlog.PostDescription,
        CategoryID:null,
        CreatedBy:loginUserID,       
        Isactive:true,
        CreateDate:new Date(Date.now())       
    }
    return this.http.post(this.rootUrl+"/api/CreateNewBlog",body,{headers:new HttpHeaders({'Authorization':'Bearer '+localStorage.getItem('userToken')})});
  }

  UpdateBLog(newBlog:BlogPost,loginUserID:number){
    const body : BlogPost={
        PostID : newBlog.PostID,
        PostTitle :newBlog.PostTitle,
        PostShortDescription:newBlog.PostShortDescription,
        PostDescription:newBlog.PostDescription,
        CategoryID:null,
        CreatedBy:loginUserID,       
        Isactive:true,
        CreateDate:new Date(Date.now())       
    }
    return this.http.post(this.rootUrl+"/api/UpdateBLog",body,{headers:new HttpHeaders({'Authorization':'Bearer '+localStorage.getItem('userToken')})});
  }
 
  addComment(comment:Comment){
    const body : Comment={
      Comment:comment.Comment,
      PostID:comment.PostID,      
      CreateDate:new Date(Date.now())       
    }
    return this.http.post(this.rootUrl+"/api/Comments",body);
  }
  
  getListBlog(){
    return this.http.get(this.rootUrl+"api/GetBlogList",{headers:new HttpHeaders({'Authorization':'Bearer '+localStorage.getItem('userToken')})});

    }
    getTop10Blog(){
      return this.http.get(this.rootUrl+"api/GetTop10Blog");  
      }

    getBlog(blogID:number){
      return this.http.get(this.rootUrl+"api/BlogPost/"+blogID,{headers:new HttpHeaders({'Authorization':'Bearer '+localStorage.getItem('userToken')})});
  
      }
      getLatestBlog(){
        return this.http.get(this.rootUrl+"api/GetLatestBlog");
    
        }
      
        getCommentList(postID:number){          
          return this.http.get(this.rootUrl+"api/Comments/"+postID);
        }
      
        deleteComment(CommentID:number){
          return this.http.delete(this.rootUrl+"api/Comments/"+CommentID,{headers:new HttpHeaders({'Authorization':'Bearer '+localStorage.getItem('userToken')})});

        }
}
