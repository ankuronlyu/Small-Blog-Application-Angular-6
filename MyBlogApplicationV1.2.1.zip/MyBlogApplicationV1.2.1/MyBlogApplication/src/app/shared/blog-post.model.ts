import { Comment } from "./comment.model";

export class BlogPost {
     PostID : number;
     PostTitle :string;
     PostShortDescription:string;
     PostDescription:string;
     CategoryID?:number;
     CreatedBy:number;
     DeletedBy?:number;
     UpdatedBy?:number;
     Isactive:boolean;
     CreateDate?:Date;
     DeleteDate?:Date;
     UpdateDate?:Date;
     Comments?:Comment;
     
}
