import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../shared/user.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {
  Isuserlogin:boolean;
  constructor(private router:Router,private userService: UserService) { }
  
  ngOnInit() {
    // if(localStorage.getItem("userDetail")){
    //   this.Isuserlogin=true;
    //   console.log("Isuserlogin"+this.Isuserlogin);
    // }
    // else{
    //   this.Isuserlogin=false;
    //   console.log("Isuserlogin"+this.Isuserlogin);
    // }
  }

  LogOut(){
    localStorage.removeItem('userToken');
    localStorage.removeItem('userRole');
    localStorage.removeItem("userDetail");
    this.router.navigate(['/login'])
  }
}
