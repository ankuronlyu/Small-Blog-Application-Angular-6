import { Component, OnInit } from '@angular/core';
import { MenuComponent } from '../menu/menu.component';
import { BlogService } from '../shared/blog.service';
import { BlogPost } from '../shared/blog-post.model';
import { Form, NgForm } from '@angular/forms';
import { Comment } from '../shared/comment.model';
import { ToastrService } from 'ngx-toastr';




@Component({
  selector: 'app-blog-list',
  templateUrl: './blog-list.component.html',
  styleUrls: ['./blog-list.component.css']
})
export class BlogListComponent implements OnInit {

  BlogsList:any;
  readBlog:any;
  currentComment:Comment
  commentList:any;
 
  
  constructor(private blogServie:BlogService,private toast:ToastrService) { }

  ngOnInit() {  
    this.getTop10Blog();
    this.getLatestBlog();  
    this.resetForm();
  }

  getTop10Blog(){
    this.blogServie.getTop10Blog().subscribe((data:any)=>{
     if(data){     
      var _blogList = [];
      data.forEach(element => {
       _blogList.push({ 
          "PostID" :element['PostID'],
          "PostTitle"  : element['PostTitle'],          
      });
      });
      this.BlogsList=_blogList;
    }    
    });
  }

  getLatestBlog(){
    //get blog details.
    this.blogServie.getLatestBlog().subscribe((data:any)=>{
      if(data){
        var selectedBlog:BlogPost={
          PostID : data['PostID'],
          PostTitle :data['PostTitle'],
          PostShortDescription:data['PostShortDescription'],
          PostDescription:data['PostDescription'],
          CategoryID:null,
          CreatedBy:null,
          Isactive:true,
          Comments:null,  
          CreateDate:new Date(Date.now())    
      }  
      };     
      this.readBlog=selectedBlog;
      if(selectedBlog){
       this.getCommentList(selectedBlog.PostID);
        this.currentComment.PostID=selectedBlog.PostID;
      }
     
      
    });
  }

  getReadBlog(ID:number){
    //get blog details.
    this.blogServie.getBlog(ID).subscribe((data:any)=>{
      if(data){
      console.log('LatestBlog.');
      console.info(data);
      var selectedBlog:BlogPost={
        PostID : data['PostID'],
        PostTitle :data['PostTitle'],
        PostShortDescription:data['PostShortDescription'],
        PostDescription:data['PostDescription'],
        CategoryID:null,
        CreatedBy:null,
        Isactive:true,
        Comments:null,
        CreateDate:new Date(Date.now())
        
      }   
      };      
      this.resetForm();
      this.readBlog=selectedBlog;
      if(selectedBlog){
        this.getCommentList(selectedBlog.PostID);
        this.currentComment.PostID=selectedBlog.PostID;
      }
      
    });
  }

  resetForm(postID?:number){
    this.currentComment={
      Comment:'',
      CommentID:null,     
      CreateDate:null,
      Isactive:null,
      PostID:postID,
    };
  }
  OnSubmitComment(form?:NgForm){
    console.info(form.value);
    this.blogServie.addComment(form.value).subscribe((data:any)=>{
      if(data!=null && data=="0"){
        this.toast.success("Comment added successfuly");
        this.resetForm();
        this.currentComment.PostID=form.value['PostID'];
        console.info(form.value);
        this.getCommentList(form.value['PostID']);
      }
      else{
        this.toast.error("Error, please try again later");
      }
    });
    
  }

  
  getCommentList(postid:number){
    this.blogServie.getCommentList(postid).subscribe((data:any)=>{
     if(data){     
      var _commentList = [];
      data.forEach(element => {
        console.info(element)
        _commentList.push({
          "CommentID":element["CommentID"],
          "Comment":element["Comment"],
          "CreateDate":element["CreateDate"],
        });
      });
      this.commentList=_commentList;
      console.info(this.commentList);
    }    
    });
  }
  
}
