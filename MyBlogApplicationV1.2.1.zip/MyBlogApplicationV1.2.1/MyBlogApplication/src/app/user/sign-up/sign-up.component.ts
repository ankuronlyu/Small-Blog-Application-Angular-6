import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms'
import { ToastrService, Toast } from 'ngx-toastr'
import { UserInfo } from '../../shared/user.model';
import { UserService } from '../../shared/user.service';


@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {
  
  emailPattern = "^[a-zA-Z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$";
  userNamePattern="^[a-zA-Z0-9]*[a-zA-Z0-9]{4,20}$";
  NamePattern="^[a-zA-Z0-9 ]*[a-zA-Z0-9  ]{2,40}$";

  user: UserInfo={
    UserID		:null,
    UserName	:null,
    FirstName	:null,
    LastName	:null,
    EmailID		:null,
    Password	:null,
    Isactive	:null,
  };

  constructor(private userService:UserService,private toastr: ToastrService) { }
  ngOnInit() {
    this.resetForm();
  }

  resetForm(form?: NgForm) {
    if (form != null)
      form.reset();
    this.user = {
      UserID		:null,
      UserName	:null,
      FirstName	:null,
      LastName	:null,
      EmailID		:null,
      Password	:null,
      Isactive	:null,

     
    }
  }
  OnSubmit(form: NgForm){
    console.log("User Registration Form Submited-->"); 
    this.userService.registerUser(form.value)
     .subscribe((data:any)=>{
       console.info(data);
       if(data!=null && data==0){
        this.resetForm(form);
        this.toastr.success('User Registration Successfully! Please login.');
      }
      else if(data!=null && data==1){
        this.toastr.warning('User Name already exists!');
       }
      else if(data!=null && (data==2 || data==3)){
        this.resetForm(form);
        this.toastr.error('User Registration Faile!');
      }
       else{                    
         this.toastr.error("Error! please try again.");
       }
     }); 
   }
}
