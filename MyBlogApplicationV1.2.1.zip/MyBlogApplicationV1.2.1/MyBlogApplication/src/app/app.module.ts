import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'
import {HttpClientModule} from '@angular/common/http'
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router'

import { AppComponent } from './app.component';
import { UserComponent } from './user/user.component';

import { appRoutes } from './routes';
import { SignUpComponent } from "./user/sign-up/sign-up.component";
import { SignInComponent } from "./user/sign-in/sign-in.component";
import { HomeComponent } from './home/home.component';
import { AuthGuard } from './auth/auth.guard';
import { UserService } from './shared/user.service';
import { AdminPanelComponent } from './admin-panel/admin-panel.component';
import { UnauthorizeComponent } from './unauthorize/unauthorize.component';
import { HomePublicComponent } from './home-public/home-public.component';
import { BlogListComponent } from './blog-list/blog-list.component';
import { MenuComponent } from './menu/menu.component';
import { MenuForPanelComponent } from './menu-for-panel/menu-for-panel.component';
import { CreateBlogComponent } from './user/create-blog/create-blog.component';





@NgModule({
  declarations: [
    AppComponent,
    SignUpComponent,
    UserComponent,
    SignInComponent,
    HomeComponent,
    AdminPanelComponent,
    UnauthorizeComponent,
    HomePublicComponent,
    BlogListComponent,
    MenuComponent,
    MenuForPanelComponent,
    CreateBlogComponent,
   
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    ToastrModule.forRoot(),
    BrowserAnimationsModule,
    RouterModule.forRoot(appRoutes),    
  ],
  providers: [UserService, AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
