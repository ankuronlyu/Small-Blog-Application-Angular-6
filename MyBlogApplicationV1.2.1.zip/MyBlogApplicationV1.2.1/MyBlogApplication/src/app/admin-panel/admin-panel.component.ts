import { Component, OnInit } from '@angular/core';
import { UserService } from '../shared/user.service';
import { UserInfo } from '../shared/user.model';
import { ToastrService } from 'ngx-toastr';
import { LIFECYCLE_HOOKS_VALUES } from '@angular/compiler/src/lifecycle_reflector';




@Component({
  selector: 'app-admin-panel',
  templateUrl: './admin-panel.component.html',
  styleUrls: ['./admin-panel.component.css']
})
export class AdminPanelComponent implements OnInit {

  UserList:any;
  constructor(private userService:UserService,private toastr: ToastrService) { }

  ngOnInit() {
   this.getUserList();
  }

  getUserList(){
    this.userService.getUserList().subscribe((data:any)=>{
      var _userArry=[];
      if(data){
        data.forEach(element => {
          _userArry.push({ 
            "UserID"		:element['UserID'],
            "UserName"	:element['UserName'],
            "FirstName"	:element['FirstName'],
            "LastName"	:element['LastName'],
            "EmailID"		:element['EmailID'],
            "Password"	:element['Passowrd'],
            "Isactive"	:element['Isactive'],
            "Roles":element["Roles"],
            "IsAdmin":element["Roles"].includes('Admin'), 
        });
        });
        this.UserList=_userArry;
        console.info(this.UserList);
      }   
    });
  }

  inActiveUser(userID:number,Isactive:boolean){
    var message=Isactive?'Do you want to inactive this user?':'Do you want to active this user?';
    if(confirm(message)==true)
    
    this.userService.inActiveUser(userID).subscribe((data:any)=>{ 
        if(data!=null && data==0){         
          this.getUserList();
          if(Isactive)
         this.toastr.success('User Inactivated Successfully! ');
         else
         this.toastr.success('User Activated Successfuly! ');
       }
       else if(data!=null && data>1){
         this.toastr.warning('Error! please try again.');
        }
    })

  }

  changeUserRole(userID:number,IsAdmin:boolean){
    console.log(userID);
    console.log(IsAdmin);
    this.userService.changeUserRole(userID,IsAdmin).subscribe((data:any)=>{
      
      if(data!=null){
        console.info(data);
        if(data=='0'){
          this.toastr.success("User role has been changed!");
          this.getUserList();
        }
       else if(data=='1'){
          this.toastr.warning("User have already access!");
         
        }
        else{
          this.toastr.error("Error, please try again later.");
        }
      }
    });
  }

}
