﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using MyBlogAPI.Entity;
using System.Security.Claims;
using MyBlogAPI.Models;

namespace MyBlogAPI.Controllers
{
    public class UserInfoesController : ApiController
    {
        private BlogDBEntities db = new BlogDBEntities();

        // GET: api/UserInfoes
        
        public IQueryable<UserInfo> GetUserInfoes()
        {
            return db.UserInfoes;
        }

        // GET: api/UserInfoes/5
      
        [ResponseType(typeof(UserInfo))]
        public IHttpActionResult GetUserInfo(int id)
        {
            UserInfo userInfo = db.UserInfoes.Find(id);
            if (userInfo == null)
            {
                return NotFound();
            }

            return Ok(userInfo);
        }
        
        // PUT: api/UserInfoes/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutUserInfo(int id, UserInfo userInfo)
        {
          
            if (id != userInfo.UserID)
            {
                return BadRequest();
            }

            db.Entry(userInfo).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!UserInfoExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/UserInfoes
        [ResponseType(typeof(UserInfo))]
        [AllowAnonymous]
        public HttpResponseMessage PostUserInfo(userInfoModel userInfo)
        {
            try
            {
                Repository.userInfoRepository userRepo = new Repository.userInfoRepository();
                return Request.CreateResponse(HttpStatusCode.OK, userRepo.UserRegistration(userInfo));
            }
            catch (Exception ex)
            {
                //TODO: Create Log with "ex" object;
                return Request.CreateResponse(HttpStatusCode.OK, MyBlogAPI.LIB.Status.Error);
            }

        }

        // DELETE: api/UserInfoes/5
        [ResponseType(typeof(UserInfo))]        
        public IHttpActionResult DeleteUserInfo(int id)
        {
            Repository.userInfoRepository userRepo = new Repository.userInfoRepository();            
            return Ok(userRepo.InactiveActiveUser(id));
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool UserInfoExists(int id)
        {
            return db.UserInfoes.Count(e => e.UserID == id) > 0;
        }

        [HttpGet]
        [Authorize]
        [Route("api/GetLoginUser")]
        public userInfoModel GetLoginUser()
        {
            var identityClaims = (ClaimsIdentity)User.Identity;
            IEnumerable<Claim> claims = identityClaims.Claims;
            userInfoModel model = new userInfoModel()
            {
                UserName = identityClaims.FindFirst("Username").Value,
                EmailID = identityClaims.FindFirst("EmailID").Value,
                FirstName = identityClaims.FindFirst("FirstName").Value,
                LastName = identityClaims.FindFirst("LastName").Value,
                LoggedOn = identityClaims.FindFirst("LoggedOn").Value,
                UserID = Convert.ToInt32(identityClaims.FindFirst("UserID").Value)
            };
            return model;
        }

        [HttpGet]
        [Authorize(Roles ="Admin")]
        [Route("api/GetUserList")]
        public List<userInfoModel> GetUserList()
        {
            Repository.userInfoRepository userRepo = new Repository.userInfoRepository();
            return userRepo.GetUsersList();            
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        [Route("api/List")]
        public List<userInfoModel> GetList()
        {
            Repository.userInfoRepository userRepo = new Repository.userInfoRepository();
            return userRepo.GetUsersList();
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        [Route("api/ChangeUserRole")]
        public LIB.Status ChangeUserRole(userInfoModel userModel)
        {
            //int id=1; bool IsAdmin=false;
            Repository.userInfoRepository userRepo = new Repository.userInfoRepository();
            return userRepo.ChangeUserRole(userModel.UserID, userModel.IsAdmin);
        }
       



    }
}