﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using MyBlogAPI.Entity;

namespace MyBlogAPI.Controllers
{
    public class CommentsController : ApiController
    {
        private BlogDBEntities db = new BlogDBEntities();

        // GET: api/Comments
        public IQueryable<Comment> GetComments()
        {
            return db.Comments;
        }

        // GET: api/Comments/5
        [ResponseType(typeof(Comment))]
        [AllowAnonymous]
        public HttpResponseMessage GetComment(int id)
        {

            int postID = Convert.ToInt32(id);
            Repository.postRepository postRepo = new Repository.postRepository();
            return Request.CreateResponse(HttpStatusCode.OK, postRepo.GetCommentList(postID));
        }

        // PUT: api/Comments/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutComment(int id, Comment comment)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != comment.CommentID)
            {
                return BadRequest();
            }

            db.Entry(comment).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CommentExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Comments
        [AllowAnonymous]
        [ResponseType(typeof(Comment))]
        public HttpResponseMessage PostComment(Models.commentModel Model)
        {

            Repository.postRepository postRepo = new Repository.postRepository();
            return Request.CreateResponse(HttpStatusCode.OK, postRepo.PostComment(Model));
        }

        // DELETE: api/Comments/5
        [ResponseType(typeof(Comment))]
        [Authorize(Roles = "Admin")]
        public IHttpActionResult DeleteComment(int id)
        {
            Comment comment = db.Comments.Find(id);
            if (comment == null)
            {
                return NotFound();
            }

            db.Comments.Remove(comment);
            int flg=db.SaveChanges();

            return Ok(flg>0?LIB.Status.success:LIB.Status.faile);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool CommentExists(int id)
        {
            return db.Comments.Count(e => e.CommentID == id) > 0;
        }
    }
}