﻿using MyBlogAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Claims;
using System.Web.Http;
using System.Web.Http.Description;

namespace MyBlogAPI.Controllers
{
    public class BlogPostController : ApiController
    {
        [ResponseType(typeof(userInfoModel))]
        [Authorize(Roles = "Admin,StandardUser")]
        [Route("api/CreateNewBlog")]
        public HttpResponseMessage PostCreateLog(postModel model)
        {
            try
            {
                var identityClaims = (ClaimsIdentity)User.Identity;
                IEnumerable<Claim> claims = identityClaims.Claims;
                if (claims != null)
                {
                    model.UserID = Convert.ToInt32(identityClaims.FindFirst("UserID").Value);
                }
                Repository.postRepository postRepo = new Repository.postRepository();
                return Request.CreateResponse(HttpStatusCode.OK, postRepo.CreateBlog(model));
            }
            catch (Exception ex)
            {
                //TODO: Create Log with "ex" object;
                return Request.CreateResponse(HttpStatusCode.OK, MyBlogAPI.LIB.Status.Error);
            }

        }

        [ResponseType(typeof(userInfoModel))]
        [Authorize(Roles = "Admin,StandardUser")]
        [Route("api/UpdateBLog")]
        public HttpResponseMessage UpdateBLog(postModel model)
        {
            try
            {
                var identityClaims = (ClaimsIdentity)User.Identity;
                IEnumerable<Claim> claims = identityClaims.Claims;
                if (claims != null)
                {
                    model.UserID = Convert.ToInt32(identityClaims.FindFirst("UserID").Value);
                }
                Repository.postRepository postRepo = new Repository.postRepository();
                return Request.CreateResponse(HttpStatusCode.OK, postRepo.UpdateBlog(model));
            }
            catch (Exception ex)
            {
                //TODO: Create Log with "ex" object;
                return Request.CreateResponse(HttpStatusCode.OK, MyBlogAPI.LIB.Status.Error);
            }

        }

        [ResponseType(typeof(List<postModel>))]
        [Authorize(Roles = "Admin,StandardUser")]
        [Route("api/GetBlogList")]
        public HttpResponseMessage GetBlogList()
        {
            var identityClaims = (ClaimsIdentity)User.Identity;
            IEnumerable<Claim> claims = identityClaims.Claims;
            int UserID = 0;
            if (claims != null)
            {
                UserID = Convert.ToInt32(identityClaims.FindFirst("UserID").Value);
            }
            Repository.postRepository postRepo = new Repository.postRepository();
            return Request.CreateResponse(HttpStatusCode.OK, postRepo.GetBlogList(UserID));
        }

        [HttpGet]
        [ResponseType(typeof(List<postModel>))]
        [AllowAnonymous]
        public HttpResponseMessage GetBlogPost(int id)
        {
            Repository.postRepository postRepo = new Repository.postRepository();
            return Request.CreateResponse(HttpStatusCode.OK, postRepo.GetBlog(id));
        }

        [ResponseType(typeof(List<postModel>))]
        [AllowAnonymous]
        [Route("api/GetTop10Blog")]
        public HttpResponseMessage GetTop10Blog()
        {
           Repository.postRepository postRepo = new Repository.postRepository();
           return Request.CreateResponse(HttpStatusCode.OK, postRepo.GetTop10Blog());
        }

        [ResponseType(typeof(List<postModel>))]
        [AllowAnonymous]
        [Route("api/GetLatestBlog")]
        public HttpResponseMessage GetLatestBlog()
        {
            Repository.postRepository postRepo = new Repository.postRepository();
            return Request.CreateResponse(HttpStatusCode.OK, postRepo.GetLatestBlog());
        }



    }
}

