﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace MyBlogAPI.Repository
{
    public class postRepository
    {
        public LIB.Status CreateBlog(Models.postModel Model)
        {
            try
            {
                if (Model != null)
                {
                    Entity.Post post = new Entity.Post
                    {
                        PostTitle = Model.PostTitle,
                        PostShortDescription = Model.PostShortDescription,
                        PostDescription = Model.PostDescription,
                        CreatedBy = Model.UserID,
                        CreateDate = DateTime.Now,
                        Isactive = true
                    };
                    using (Entity.BlogDBEntities db = new Entity.BlogDBEntities())
                    {
                        db.Posts.Add(post);
                        db.SaveChanges();
                        if (post != null && post.PostID > 0)
                        {
                            return LIB.Status.success;
                        }
                        else
                        {
                            return LIB.Status.faile;
                        }
                    }

                }
                else
                {
                    return LIB.Status.faile;
                }
            }
            catch (Exception)
            {
                //create log
                return LIB.Status.faile;
                //throw;
            }
            
        }

        public LIB.Status UpdateBlog(Models.postModel Model)
        {
            try
            {
                if (Model != null)
                {

                    using (Entity.BlogDBEntities db = new Entity.BlogDBEntities())
                    {
                        Entity.Post post = db.Posts.Where(n => n.PostID == Model.PostID).FirstOrDefault();
                        post.PostTitle = Model.PostTitle;
                        post.PostDescription = Model.PostDescription;
                        post.PostDescription = Model.PostDescription;
                        post.UpdateDate = DateTime.Now;
                        post.UpdatedBy = Model.UserID;
                        db.Entry(post).State = EntityState.Modified;
                        int flg = db.SaveChanges();
                        if (flg > 0)
                        {
                            return LIB.Status.success;
                        }
                        else
                        {
                            return LIB.Status.faile;
                        }
                    }

                }
                else
                {
                    return LIB.Status.faile;
                }
            }
            catch (Exception)
            {
                return LIB.Status.faile;
                //throw;
            }
           
        }

        public List<Models.postModel> GetBlogList(int UserID)
        {
            List<Models.postModel> BlogList = null;
            try
            {
                if (UserID > 0)
                {
                    using (Entity.BlogDBEntities db = new Entity.BlogDBEntities())
                    {
                        List<string> RoleList = (from n in db.UserInfoes
                                                 join r in db.UserRoles on n.UserID equals r.UserID
                                                 where n.UserID == UserID
                                                 select (r.Role.RoleName)).ToList();

                        if (RoleList != null && RoleList.Contains("Admin"))
                        {
                            BlogList = (from n in db.Posts
                                        select new Models.postModel
                                        {
                                            PostID = n.PostID,
                                            PostTitle = n.PostTitle,
                                            PostShortDescription = n.PostShortDescription,
                                            Isactive = n.Isactive

                                        }).ToList();
                            return BlogList;
                        }
                        else
                        {
                            BlogList = (from n in db.Posts
                                        where n.CreatedBy == UserID && n.Isactive == true
                                        select new Models.postModel
                                        {
                                            PostID = n.PostID,
                                            PostTitle = n.PostTitle,
                                            PostShortDescription = n.PostShortDescription,
                                            Isactive = n.Isactive

                                        }).ToList();

                            return BlogList;

                        }
                    }
                }
                else
                {
                    return BlogList;
                }
            }
            catch (Exception)
            {
                return BlogList;
                throw;
            }
            
           
        }

        public Models.postModel GetBlog(int BlogID)
        {
            Models.postModel blog = new Models.postModel();
            try
            {
                using (Entity.BlogDBEntities db = new Entity.BlogDBEntities())
                {
                    blog = (from n in db.Posts
                            where n.PostID == BlogID
                            select new Models.postModel
                            {
                                PostID = n.PostID,
                                PostTitle = n.PostTitle,
                                PostShortDescription = n.PostShortDescription,
                                PostDescription = n.PostDescription,
                                Isactive = n.Isactive

                            }).FirstOrDefault();
                }
                return blog;
            }
            catch (Exception)
            {
                return blog;
                throw;
            }
           
            
        }


        public List<Models.postModel> GetTop10Blog()
        {
            List<Models.postModel> blog = null;
            try
            {
               
                using (Entity.BlogDBEntities db = new Entity.BlogDBEntities())
                {
                    blog = (from n in db.Posts
                            select new Models.postModel
                            {
                                PostID = n.PostID,
                                PostTitle = n.PostTitle,
                                PostShortDescription = n.PostShortDescription,
                                Isactive = n.Isactive,
                                CreateDate = n.CreateDate

                            }).OrderByDescending(n => n.PostID).ToList();
                }
                return blog;
            }
            catch (Exception)
            {
                return blog;
            }
            
        }

        public Models.postModel GetLatestBlog()
        {
            Models.postModel blog = new Models.postModel();
            try
            {
                using (Entity.BlogDBEntities db = new Entity.BlogDBEntities())
                {
                    blog = (from n in db.Posts
                            select new Models.postModel
                            {
                                PostID = n.PostID,
                                PostTitle = n.PostTitle,
                                PostShortDescription = n.PostShortDescription,
                                PostDescription = n.PostDescription,
                                Isactive = n.Isactive,
                                CreateDate = n.CreateDate

                            }).OrderByDescending(n => n.PostID).Take(1).FirstOrDefault();

                }
                return blog;
            }
            catch (Exception)
            {
                return blog;
            }
          
        }

        public LIB.Status PostComment(Models.commentModel Model)
        {
            try
            {
                if (Model != null)
                {
                    Entity.Comment comment = new Entity.Comment
                    {
                        Comment1=Model.Comment,
                        CommentID=Model.CommentID,
                        PostID=Model.PostID,
                        CreateDate=DateTime.Now,
                    };
                    using (Entity.BlogDBEntities db = new Entity.BlogDBEntities())
                    {
                        db.Comments.Add(comment);
                        db.SaveChanges();
                        if (comment != null && comment.CommentID > 0)
                        {
                            return LIB.Status.success;
                        }
                        else
                        {
                            return LIB.Status.faile;
                        }
                    }

                }
                else
                {
                    return LIB.Status.faile;
                }
            }
            catch (Exception ex)
            {
                //create log
                return LIB.Status.faile;
                //throw;
            }

        }

        public List<Models.commentModel> GetCommentList(int PostID)
        {
            List<Models.commentModel> commentList = null;
            try
            {
                using (Entity.BlogDBEntities db = new Entity.BlogDBEntities())
                {
                    commentList = (from n in db.Comments
                            where n.PostID == PostID
                            select new Models.commentModel
                            {
                                PostID = n.PostID,
                                Comment = n.Comment1,
                                CreateDate = n.CreateDate,
                                Isactive = n.Isactive,
                                CommentID=n.CommentID,

                            }).OrderByDescending(n => n.CreateDate).ToList();
                }
                return commentList;
            }
            catch (Exception ex)
            {
                return commentList;
                throw;
            }


        }
    }
}