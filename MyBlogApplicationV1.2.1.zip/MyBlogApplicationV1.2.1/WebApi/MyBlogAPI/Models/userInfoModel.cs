﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyBlogAPI.Models
{
    public class userInfoModel
    {
        public int UserID { get; set; }
        public string UserName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmailID { get; set; }
        public string Password { get; set; }
        public bool Isactive { get; set; }
        public DateTime CreateDate { get; set; }
        public DateTime? DeleteDate { get; set; }
        public DateTime? UpdateDate { get; set; }
        public List<string> Roles { get; set; }
        public string LoggedOn { get; internal set; }
        public bool IsAdmin { get; set; }
    }
}