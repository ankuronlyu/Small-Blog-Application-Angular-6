﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyBlogAPI.Models
{
    public class commentModel
    {
        public int CommentID { get; set; }
        public string Comment { get; set; }
        public Nullable<int> PostID { get; set; }
        public Nullable<int> IsReply { get; set; }
        public Nullable<int> ParentCommentID { get; set; }
        public int? CreatedBy { get; set; }
        public Nullable<int> DeletedBy { get; set; }
        public Nullable<int> UpdatedBy { get; set; }
        public bool Isactive { get; set; }
        public System.DateTime CreateDate { get; set; }
        public Nullable<System.DateTime> DeleteDate { get; set; }
        public Nullable<System.DateTime> UpdateDate { get; set; }
    }
}
